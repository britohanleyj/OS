#ifndef RANDOM_CPP
#define RANDOM_CPP

void rand_init(int);
int scaled_random(int,int);

#endif


