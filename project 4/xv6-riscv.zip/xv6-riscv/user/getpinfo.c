#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
#include "kernel/fcntl.h"
#include "kernel/pstat.h"

int
main(int argc, char **argv)
{
    struct pstat pinfo;
    getpinfo(&pinfo);
    for (int i=0; i < NPROC; ++i)
     {
     printf("%d", pinfo.inuse[i]);
     printf("%s", " Inuse, ");
     printf("%d", pinfo.tickets[i]);
     printf("%s", " Tickets, ");
     printf("%d", pinfo.pid[i]);
     printf("%s", " PID,");
     printf("%d", pinfo.ticks[i]);
     printf("%s", " Ticks \n");
     }
 return 0;
}